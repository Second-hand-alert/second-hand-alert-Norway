(function (factory) {
	typeof define === 'function' && define.amd ? define(factory) :
	factory();
})((function () { 'use strict';

	console.log('### ########################## Hello content at Reima in Firefox! ###');

}));
